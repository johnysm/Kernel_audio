
#include "my_wm8960.h"




/*
struct regmap_range_cfg - Configuration for indirectly accessed or paged
 *                           registers.
 *
 * Registers, mapped to this virtual range, are accessed in two steps:
 *     1. page selector register update;
 *     2. access through data window registers.
*/

static const struct regmap_range_cfg wm8960_regmap_pages[] = {
	{
		.selector_reg = 0,				//	Register with selector field.
		.selector_mask	= 0xff,			//	Bit mask for selector value.
		.window_start = 0,				//	Address of first (lowest) register in data window.
		.window_len = 128,				//	Number of registers in data window.
		.range_min = 0,				//	Address of the lowest register address in virtual range.
		.range_max = WM8960_REFPOWERUP,		//	Address of the highest register in virtual range.
	},
};

/**
 * struct regmap_config - Configuration for the register map of a device.
 *
 * @name: Optional name of the regmap. Useful when a device has multiple
 *        register regions.
 */

const struct regmap_config wm8960_regmap_config = {
	.max_register = WM8960_REFPOWERUP,
	.ranges = wm8960_regmap_pages,
	.num_ranges = ARRAY_SIZE(wm8960_regmap_pages),
};
EXPORT_SYMBOL(wm8960_regmap_config);
