#include <linux/i2c.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/regmap.h>
#include <sound/soc.h>

#include "my_wm8960.h"



dev_t dev = 0;
static struct class *dev_class;
static struct cdev char_cdev;

/*Prototype of all file operation for character driver*/
static int      char_open(struct inode *inode, struct file *file);
static int      char_release(struct inode *inode, struct file *file);
static ssize_t  char_read(struct file *filp, char __user *buf, size_t len,loff_t * off);
static ssize_t  char_write(struct file *filp, const char *buf, size_t len, loff_t * off);

static struct file_operations fops =
{
    .owner      = THIS_MODULE,
    .read       = char_read,
    .write      = char_write,
    .open       = char_open,
    .release    = char_release,
};

/*
** This function will be called when we open the Device file
*/
static int char_open(struct inode *inode, struct file *file)
{
        pr_info("Driver Open Function Called...!!!\n");
        return 0;
}
/*
** This function will be called when we close the Device file
*/
static int char_release(struct inode *inode, struct file *file)
{
        pr_info("Driver Release Function Called...!!!\n");
        return 0;
}
/*
** This function will be called when we read the Device file
*/
static ssize_t char_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
        pr_info("Driver Read Function Called...!!!\n");
        return 0;
}
/*
** This function will be called when we write the Device file
*/
static ssize_t char_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
        pr_info("Driver Write Function Called...!!!\n");
        return len;
}

static int my_wm8960_i2c_probe(struct i2c_client *i2c,
                         const struct i2c_device_id *id)
{
	
	 /*Allocating Major number*/
        if((alloc_chrdev_region(&dev, 0, 1, "char_Dev")) <0){
                pr_info("Cannot allocate major number\n");
                return -1;
        }
        pr_info("Major = %d Minor = %d \n",MAJOR(dev), MINOR(dev));
 
        /*Creating cdev structure*/
        cdev_init(&char_cdev,&fops);
 
        /*Adding character device to the system*/
        if((cdev_add(&char_cdev,dev,1)) < 0){
            pr_info("Cannot add the device to the system\n");
            goto r_class;
        }
 
        /*Creating struct class*/
        if((dev_class = class_create(THIS_MODULE,"char_class")) == NULL){
            pr_info("Cannot create the struct class\n");
            goto r_class;
        }
 
        /*Creating device*/
        if((device_create(dev_class,NULL,dev,NULL,"char_device")) == NULL){
            pr_info("Cannot create the Device \n");
            goto r_device;
        }
        pr_info("Device Driver Insert...Done!!!\n");
        return 0;
 
r_device:
        class_destroy(dev_class);
r_class:
        unregister_chrdev_region(dev,1);
        return -1;
	
	struct regmap *regmap;
	regmap = devm_regmap_init_i2c(i2c, &wm8960_regmap);
	return my_wm8960_probe(&i2c->dev, regmap);
	

    return 0;
}

 
/*
** This function getting called when the slave has been removed
** Note : This will be called only once when we unload the driver.
*/
static int my_wm8960_i2c_remove(struct i2c_client *client)
{   
   
	device_destroy(dev_class,dev);
        class_destroy(dev_class);
        cdev_del(&char_cdev);
        unregister_chrdev_region(dev, 1);
        pr_info("Device Driver Remove...Done!!!\n");
   
	return 0;
}
 
/*
** Structure that has slave device id
*/
static const struct i2c_device_id my_wm8960_id[] = {
        { SLAVE_DEVICE_NAME, WM8960_SLAVE_ADDR },
        { }
};
MODULE_DEVICE_TABLE(i2c, my_wm8960_id);

/*
** I2C driver Structure that has to be added to linux
*/
static struct i2c_driver my_wm8960_codec_driver = {
		.class          = I2C_CLASS_DEPRECATED,
        .driver = {
            .name   = SLAVE_DEVICE_NAME,
            .owner  = THIS_MODULE,
        },
        .probe          = my_wm8960_i2c_probe,
        .remove         = my_wm8960_i2c_remove,
        .id_table       = my_wm8960_id,
};
 
/*
** I2C Board Info strucutre
*/
static struct i2c_board_info wm8960_i2c_board_info = {
        I2C_BOARD_INFO(SLAVE_DEVICE_NAME, WM8960_SLAVE_ADDR)
    };
 
/*
** Module Init function
*/
static int __init my_driver_init(void)
{
    int ret = -1;
    my_i2c_adapter = i2c_get_adapter(I2C_BUS_AVAILABLE);
    
    if( my_i2c_adapter != NULL )
    {
        my_i2c_client_wm8960 = i2c_new_client_device(my_i2c_adapter, &wm8960_i2c_board_info);
        
        if( my_i2c_client_wm8960 != NULL )
        {
            ret = i2c_add_driver(&my_wm8960_codec_driver);
            if(ret) {
				pr_info("Error: i2c_add_driver failed");				
			}
        }
		else
		{
			pr_info("Error: Device not added");
		}
        
        i2c_put_adapter(my_i2c_adapter);
		pr_info("Driver Added!!! ret %d\n",ret);
    }
	else
	{
		pr_info("Error: adapter not created");
	}
    
    return ret;
}
 
/*
** Module Exit function
*/
static void __exit my_driver_exit(void)
{
    i2c_unregister_device(my_i2c_client_wm8960);
    i2c_del_driver(&my_wm8960_codec_driver);
    pr_info("Driver Removed!!!\n");
}
 
module_init(my_driver_init);
module_exit(my_driver_exit);
 
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pallavi Sonekar");
MODULE_DESCRIPTION("wm8960 codec");
